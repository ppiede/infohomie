import { React } from "react";

const Help = () => {
  return (
    <div>
      <p>Hier ist Platz, um einen bestehenden Baum zu bearbeiten</p>
    </div>
  );
};

export default Help;
