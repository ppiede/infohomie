// Imports
import { React } from "react";


const Help = () => {
  return (
    <div>
      <p>Hier ist Platz für Anleitung und Erklärungen</p>
    </div>
  );
};

export default Help;
