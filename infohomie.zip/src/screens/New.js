import { React } from "react";

const Help = () => {
  return (
    <div>
      <p>Hier ist Platz, um einen neuen Baum zu erstellen</p>
    </div>
  );
};

export default Help;
