# infohomie
Eine qualifizierte Homepage, um Entscheidungsbäume schulintern zu publishen.
